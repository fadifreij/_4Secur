﻿namespace _4secwebservice;

public static class Api
{
    public static void ConfigureApi(this WebApplication app)
    {
        // All api end point mappings
        app.MapGet("/License", GetLicense);
        app.MapPost("/License", UpdateLicense);
    }

    public static async Task<IResult> GetLicense(IFileData data)
    {
        try
        {
            return Results.Ok(await data.LicenseGet());
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    public static IResult UpdateLicense(License lic,IFileData data)
    {
        try
        {
             data.LicenseUpdate(lic);
            return Results.Ok();
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }
}
