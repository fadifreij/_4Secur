﻿using Newtonsoft;
using System.Text.Json;

namespace _4secwebservice;


public class FileData : IFileData
{
   
    public Task<License?> LicenseGet()
    {
        string getfilecontent = File.ReadAllText(GetFileName());
        License? objLic = JsonSerializer.Deserialize<License?>(getfilecontent);
        
        return Task.FromResult(objLic);
    }

    public void LicenseUpdate(License lic)
    {
        string strjson = JsonSerializer.Serialize(lic);
        File.WriteAllText(GetFileName(), strjson);
    }

    private string GetFileName()
    {
        string curDir = Directory.GetCurrentDirectory();

        return Path.Combine(curDir,"license-config.json");
    }
}
