﻿namespace _4secwebservice;

public interface IFileData
{
    Task<License?> LicenseGet();
    void LicenseUpdate(License lic);
}