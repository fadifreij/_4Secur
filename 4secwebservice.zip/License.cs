﻿namespace _4secwebservice;

public record License(string LicenseNumber, string Client);

