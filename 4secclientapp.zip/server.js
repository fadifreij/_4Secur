
'use strict'

const Hapi = require('hapi');
const Request = require('request');
const Vision = require('vision');
const Handlebars = require('handlebars');
const LodashFilter = require('lodash.filter');
const LodashTake = require('lodash.take');
const Joi = require("joi");

const server = new Hapi.Server();
let licenseinfo;

server.connection({
    host: '127.0.0.1',
    port: 8080
});

// Register vision for our views
server.register(Vision, (err) => {
    server.views({
        engines: {
            html: Handlebars
        },
        relativeTo: __dirname,
        path: './views',
    });
});

server.start((err) => {
    if (err) {
        throw err;
    }

    console.log(`Server running at: ${server.info.uri}`);
});


server.route({
    method: 'GET',
    path: '/',
    handler: function (request, reply) {
        Request.get('http://localhost:5011/License', function (error, response) {
            if (error) {
                throw error;
            }
            console.log(`TestGet: ${response.body}`);            
            const data = JSON.parse(response.body);
            licenseinfo= postData = data;
            reply.view('index', { postData: data });
        });
    }
});


var postData = {
    licenseNumber: 'test',
    client: 'test'
  }
  
  
server.route({
    method: 'POST',
    path: '/license',    
    handler:     
    (request, reply)=> {       
         const data = JSON.stringify(request.payload);
            console.log(`TestPost: ${data}`); 
            var options = {
                method: 'post',
                url: 'http://localhost:5011/License',
                headers: {"Content-Type": "application/json"},
                body: data,
            }; 
            Request(options, function(error, response, body) {
                console.log(data);
            }); 
           // reply.close();
           // reply.redirect('index', { postData: data });
    }
});
